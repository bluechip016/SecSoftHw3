def attack(output, elapsed):
    return "Implement here"