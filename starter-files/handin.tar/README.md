# Answers for part 2.4 (Static vs. Dynamic Non-Interference)

TODO: Add your answers here!


# Extra Credit Writeup

TODO: 
If you decide to attempt the extra credit, for each section below, describe why
your program passes the security checks, how it leaks secret information, and
what limitation of the non-interference theorem your attack exploits.

## Security Type Leak

## Taint Analysis Leak
